package ru.grandbuilds;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ru.grandbuilds.build.BuildType;
import ru.grandbuilds.build.Placer;

import java.util.Arrays;

@Mod.EventBusSubscriber(modid = GrandBuilds.MODID)
public final class BuildCommand {
    private BuildCommand() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("grand")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("list").executes(ctx -> {
                    StringBuilder sb = new StringBuilder("Постройки:");
                    for (BuildType t : BuildType.values()) sb.append("\n  ").append(t.id).append(" — ").append(t.title);
                    ctx.getSource().sendSuccess(() -> Component.literal(sb.toString()), false);
                    return 1;
                }))
                .then(Commands.literal("undo").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    boolean ok = Placer.undo(p.getUUID());
                    ctx.getSource().sendSuccess(() -> Component.literal(ok ? "Последняя постройка убрана." : "Нечего отменять."), false);
                    return ok ? 1 : 0;
                }))
                .then(Commands.literal("build")
                        .then(Commands.argument("type", StringArgumentType.word())
                                .suggests((ctx, b) -> SharedSuggestionProvider.suggest(Arrays.stream(BuildType.values()).map(t -> t.id), b))
                                .executes(ctx -> build(ctx.getSource(), StringArgumentType.getString(ctx, "type"), 3))
                                .then(Commands.argument("distance", IntegerArgumentType.integer(0, 64))
                                        .executes(ctx -> build(ctx.getSource(), StringArgumentType.getString(ctx, "type"),
                                                IntegerArgumentType.getInteger(ctx, "distance")))))));
    }

    private static int build(CommandSourceStack src, String id, int dist) throws CommandSyntaxException {
        BuildType t = BuildType.byId(id);
        if (t == null) {
            src.sendFailure(Component.literal("Неизвестная постройка: " + id + ". Список: /grand list"));
            return 0;
        }
        ServerPlayer p = src.getPlayerOrException();
        BlockPos ground = p.blockPosition().below().relative(p.getDirection(), dist);
        int n = Placer.place(p.serverLevel(), ground, p.getDirection(), t, p.getUUID());
        src.sendSuccess(() -> Component.literal("Построено: " + t.title + " (" + n + " блоков). Отмена: /grand undo"), true);
        return 1;
    }
}
