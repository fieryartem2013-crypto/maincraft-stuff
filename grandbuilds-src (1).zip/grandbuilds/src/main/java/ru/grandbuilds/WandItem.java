package ru.grandbuilds;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import ru.grandbuilds.build.BuildType;
import ru.grandbuilds.build.Placer;

import javax.annotation.Nullable;
import java.util.List;

public class WandItem extends Item {
    public WandItem() {
        super(new Item.Properties().stacksTo(1));
    }

    private static BuildType selected(ItemStack st) {
        BuildType[] all = BuildType.values();
        return all[Math.floorMod(st.getOrCreateTag().getInt("Sel"), all.length)];
    }

    private static void cycle(ItemStack st, Player p, Level level) {
        int n = (st.getOrCreateTag().getInt("Sel") + 1) % BuildType.values().length;
        st.getOrCreateTag().putInt("Sel", n);
        if (!level.isClientSide) {
            p.displayClientMessage(Component.literal("Выбрано: " + selected(st).title), true);
        }
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack st = p.getItemInHand(hand);
        if (p.isShiftKeyDown()) {
            cycle(st, p, level);
            return InteractionResultHolder.sidedSuccess(st, level.isClientSide);
        }
        return InteractionResultHolder.pass(st);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Player p = ctx.getPlayer();
        Level level = ctx.getLevel();
        if (p == null) return InteractionResult.PASS;
        ItemStack st = ctx.getItemInHand();
        if (p.isShiftKeyDown()) {
            cycle(st, p, level);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BuildType t = selected(st);
        BlockPos ground = ctx.getClickedPos();
        int n = Placer.place((ServerLevel) level, ground, p.getDirection(), t, p.getUUID());
        p.displayClientMessage(Component.literal("Построено: " + t.title + " (" + n + " блоков). Отмена: /grand undo"), true);
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack st, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.literal("Постройка: " + selected(st).title));
        tip.add(Component.literal("ПКМ по земле — построить (вперёд от вас)"));
        tip.add(Component.literal("Shift+ПКМ — сменить постройку"));
    }
}
